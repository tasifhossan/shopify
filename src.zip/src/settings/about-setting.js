export const aboutSetting = {
    titleOne: 'about-one-title',
    titleTwo: 'about-two-title',
    titleThree: 'about-three-title',
    descriptionOne: 'about-one-content',
    descriptionTwo: 'about-two-content',
    descriptionThree: 'about-three-content',
    descriptionFour: 'about-four-content',
    descriptionFive: 'about-five-content',
};
