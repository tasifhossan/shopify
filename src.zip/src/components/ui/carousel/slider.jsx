'use client';

import 'swiper/css';
export { Navigation, Thumbs, Pagination, Autoplay, Grid } from 'swiper/modules';
export { Swiper, SwiperSlide } from 'swiper/react';
