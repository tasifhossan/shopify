import RCPagination from 'rc-pagination';
import 'rc-pagination/assets/index.css';

const Pagination = (props) => {
    return <RCPagination {...props} />;
};

export default Pagination;
