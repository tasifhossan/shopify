﻿export default function Page() { return <div>Placeholder for src/app/admin/categories</div> }
