'use client';

import { ToastContainer } from 'react-toastify';

const ToasterProvider = () => {
    return <ToastContainer />;
};

export default ToasterProvider;
