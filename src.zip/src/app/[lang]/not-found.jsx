import ErrorInformation from '@components/404/error-information';

export default function NotFound() {
    return <ErrorInformation />;
}
