﻿export default function Page() { return <div>Placeholder for src/app/complete-order</div> }
