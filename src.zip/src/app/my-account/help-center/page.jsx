﻿export default function Page() { return <div>Placeholder for src/app/my-account/help-center</div> }
