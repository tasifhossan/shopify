﻿export default function Page() { return <div>Placeholder for src/app/my-account/change-password</div> }
