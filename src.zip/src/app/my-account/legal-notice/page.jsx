﻿export default function Page() { return <div>Placeholder for src/app/my-account/legal-notice</div> }
