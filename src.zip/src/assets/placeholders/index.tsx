export { default as productPlaceholder } from '@assets/placeholders/product.png';
export { default as productGalleryPlaceholder } from '@assets/placeholders/product-placeholder.png';
export { default as searchProductPlaceholder } from '@assets/placeholders/search-product.png';
export { default as categoryPlaceholder } from '@assets/placeholders/category.png';
export { default as collectionPlaceholder } from '@assets/placeholders/collection.svg';
